#include <iostream>
#include <regex>
#include <string>

using namespace std;

string readAndRem(const string& program) {
    regex pattern("/\\*([^*]|(\\*+[^*/]))*\\*+/|//.*");
    return regex_replace(program, pattern, "");
}

int main() {
    string program = R"(
        int x; // declared var x
        x = 5; /* Assigning a value 5 to x */
        // Print the value of x
        cout << "The value of x is: " << x;
    )";

    string result = readAndRem(program);
    cout << result << endl;

    return 0;
}
