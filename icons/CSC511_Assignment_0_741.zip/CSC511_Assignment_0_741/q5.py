# Importing required modules
from collections import defaultdict

# Function to read NFA from the text file and return the NFA as a dictionary
def read_nfa_from_file(file_path):
    nfa = defaultdict(lambda: defaultdict(set))
    with open(file_path, 'r') as file:
        for line in file:
            source, symbol, target = line.strip().split()
            nfa[source][symbol].add(target)
    return nfa

# Function to perform epsilon closure on a state in the NFA
def epsilon_closure(nfa, state):
    closure = set()
    stack = [state]
    while stack:
        current_state = stack.pop()
        closure.add(current_state)
        for next_state in nfa[current_state]['eps']:
            if next_state not in closure:
                stack.append(next_state)
    return closure

# Function to perform epsilon closure on a set of states in the NFA
def epsilon_closure_set(nfa, states):
    closure = set()
    for state in states:
        closure.update(epsilon_closure(nfa, state))
    return closure

# Function to move from a set of states in the NFA given a symbol
def move(nfa, states, symbol):
    move_states = set()
    for state in states:
        move_states.update(nfa[state][symbol])
    return move_states

# Function to convert NFA to DFA using the subset construction algorithm
def nfa_to_dfa(nfa):
    dfa = defaultdict(lambda: defaultdict(set))
    start_state = frozenset(epsilon_closure(nfa, '0'))
    queue = [start_state]
    visited = {start_state}
    while queue:
        current_state = queue.pop(0)
        for symbol in nfa['0'].keys():
            move_states = move(nfa, current_state, symbol)
            closure = frozenset(epsilon_closure_set(nfa, move_states))
            dfa[current_state][symbol] = closure
            if closure not in visited:
                visited.add(closure)
                queue.append(closure)
    return dfa


# Function to write DFA to a text file
def write_dfa_to_file(dfa, file_path):
    with open(file_path, 'w') as file:
        for state in dfa:
            for symbol in dfa[state]:
                target_states = dfa[state][symbol]
                for target_state in target_states:
                    file.write(f"{state} {symbol} {target_state}\n")

# Main function
def main():
    input_file = 'nfa_input.txt' # input file path
    output_file = 'dfa_output.txt' #output file path

    nfa = read_nfa_from_file(input_file)
    dfa = nfa_to_dfa(nfa)
    
   

    write_dfa_to_file(dfa, output_file)
    print("NFA to DFA conversion completed!")

if __name__ == "__main__":
    main()
