#include <iostream>
#include <regex>
#include <string>
#include <unordered_set>
#include <vector>

using namespace std;

vector<string> recogkeys(const string& program) {
    vector<string> keywords;
    unordered_set<string> keys = { //these are a few keywords any key enterd in this set will be identified
        "auto", "break", "case", "char","continue", "do",
        "double", "else", "float", "for", "if","int", 
        "long", "register", "return", "short", "signed", 
        "sizeof", "static", "void", "volatile", "while","cout","cin"
    };

    regex pattern("\\b[a-zA-Z_][a-zA-Z0-9_]*\\b");
    sregex_iterator iter(program.begin(), program.end(), pattern);
    sregex_iterator end;

    while (iter != end) {
        string word = iter->str();
        if (keys.count(word) > 0) {
            keywords.push_back(word);
        }
        ++iter;
    }

    return keywords;
}

int main() {
    string program = "int x; if (x > 0) { cout << \"Positive\"; } else { cout << \"Non-positive\"; }";
    vector<string> result = recogkeys(program);

    for (const auto& keyword : result) {
        cout << keyword << endl;
    }

    return 0;
}
