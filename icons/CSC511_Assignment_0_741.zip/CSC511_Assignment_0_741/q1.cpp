#include <bits/stdc++.h>

using namespace std;

vector<string> recogid(const string& program) {
    vector<string> ans;
    regex pattern("\\b[a-zA-Z_][a-zA-Z0-9_]*\\b");
    sregex_iterator iter(program.begin(), program.end(), pattern);
    sregex_iterator end;

    while (iter != end) {
        ans.push_back(iter->str());
        ++iter;
    }

    return ans;
}

int main() {
    //example
    string program = "int x = 7; float y = 3.141569; string name = 'Shubh';";
    vector<string> result = recogid(program);

    for (const auto& identifier : result) {
        cout << identifier << endl;
    }

    return 0;
}
