#include <iostream>
#include <string>
using namespace std;

bool isValid(const string& id) {
    int currentState = 0;
    int automaton[2][3] = {
        {1, -1, -1},  // Transition table for the initial state (0)
        {1, 1, 1},    // Transition table for the accepting state (1)
    };

    for (char ch : id) {
        int inputType = 0;
        if (isalpha(ch))
            inputType = 0;
        else if (isdigit(ch))
            inputType = 1;
        else if (ch == '_')
            inputType = 2;

        int nextState = automaton[currentState][inputType];
        if (nextState == -1)
            return false;
        currentState = nextState;
    }

    return currentState == 1;
}

int main() {
    // Test the automaton with example
    string exampleSet[] = {
        "variable123",
        "MyVariable",
        "_var",
        "1invalid",
        "$invalid",
    };

    for (const string& id : exampleSet) {
        bool result = isValid(id);
        cout << id << ": " << (result ? "Valid" : "Invalid") << endl;
    }

    return 0;
}
