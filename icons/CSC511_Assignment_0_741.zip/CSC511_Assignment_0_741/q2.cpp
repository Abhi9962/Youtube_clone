#include <iostream>
#include <regex>
#include <string>
#include <vector>

using namespace std;

vector<string> recogIOS(const string& program) {
    vector<string> statements;
    regex inPattern("cin\\s*>>");
    regex outPattern("cout\\s*<<");

    smatch match;
    string::const_iterator searchStart(program.cbegin());

    while (regex_search(searchStart, program.cend(), match, inPattern)) {
        statements.push_back(match.str());
        searchStart = match.suffix().first;
    }

    searchStart = program.cbegin();

    while (regex_search(searchStart, program.cend(), match, outPattern)) {
        statements.push_back(match.str());
        searchStart = match.suffix().first;
    }

    return statements;
}

int main() {
    string program = "string x; cin >> x; cout << \"The value of x is: \" << x;";
    vector<string> result = recogIOS(program);

    for (const auto& statement : result) {
        cout << statement << endl;
    }

    return 0;
}
